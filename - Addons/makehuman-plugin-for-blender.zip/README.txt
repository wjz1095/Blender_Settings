Do not extract this file. It should be installed as an addon zip in blender.
