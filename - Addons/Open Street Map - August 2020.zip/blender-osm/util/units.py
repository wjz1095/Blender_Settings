


def fromUnits(value, units=None):
    """
    The function is supposed to convert from the given <units> to
    the internal system of units (meters)
    """
    return value


def toUnits(value, units):
    """
    The function is supposed to convert from the internal system of units (meters)
    to the given <units>
    """
    return value